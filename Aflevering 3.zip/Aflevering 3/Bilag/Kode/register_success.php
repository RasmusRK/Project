<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Secure Login: Registration Success</title>
        <link rel="stylesheet" href="styles/main.css" />
    </head>
    <body>
        <h1>Brugeren er nu oprettet!</h1>
        <p>Du kan nu gå tilbage til <a href="index.php">login siden</a> og logge ind.</p>
    </body>
</html>